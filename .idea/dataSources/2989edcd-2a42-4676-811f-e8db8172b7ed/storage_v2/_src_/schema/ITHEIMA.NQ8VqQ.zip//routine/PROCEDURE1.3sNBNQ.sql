create procedure procedure1(emo emp1.empno%type)
is
   --记录实时工资
   sal2 emp1.sal%type;
begin
  select sal into sal2 from emp1 where empno=emo;
  dbms_output.put_line('原来工资是:'||sal2);
  update emp1 set sal=sal+100 where empno=emo;
  commit;
  select sal into sal2 from emp1 where empno=emo;
  dbms_output.put_line('现在工资是:'||sal2);
end;
/

