create procedure procedure2(emo emp1.empno%type , yearsal out number)
is
       ems emp1.sal%type;--月薪
       emc emp1.comm%type;--奖金
       --yearsal number(10);--年薪
begin
  select sal*12,nvl(comm,0) into ems,emc from emp1 where empno=emo;
  yearsal :=ems+emc;
end;
/

